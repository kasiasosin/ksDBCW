
# Kasia Sosin - DBI Coursework 2
All aspects of the coursework have been attempted. Information about each section of the coursework are detailed below.

##  HTML

Lighthouse Accessibility Tests: 100% Passed.

## CSS

Line 25 in the styles.css file uses location selector to remove bullet points from the navigation links.


## JavaScript

Additional messages have been provided to the user as well as error and success to explain the nature of the errors and success.

## Additional Info